# Solana Bot Setup Guide
1. RPC Endpoint
2. Wallet Config